# ch340_driver
The ch340 driver is available for windows, mac, linux and Android.
